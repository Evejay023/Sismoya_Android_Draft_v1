package com.example.waterrefilldraftv1.Customer.network;

import com.example.waterrefilldraftv1.Customer.models.AddressResponse;
import com.example.waterrefilldraftv1.Customer.models.ApiResponse;
import com.example.waterrefilldraftv1.Customer.models.OrderRequest;
import com.example.waterrefilldraftv1.Customer.models.RegisterRequest;
import com.example.waterrefilldraftv1.Login_Customer_and_Riders.LoginRequest;
import com.example.waterrefilldraftv1.Customer.models.LoginResponse;
import com.example.waterrefilldraftv1.Customer.models.ForgotPasswordRequest;
import com.example.waterrefilldraftv1.Customer.models.VerifyCodeRequest;
import com.example.waterrefilldraftv1.Customer.models.ResetPasswordRequest;
import com.example.waterrefilldraftv1.Customer.models.User;
import com.example.waterrefilldraftv1.Customer.models.Address;
import com.example.waterrefilldraftv1.Customer.models.ProductDto;

import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Path;
import retrofit2.http.Url;

public interface ApiService {

    // ======================================================
    // ✅ ACCOUNT SETTINGS (Replaces /profile)
    // ✅ Fetch user profile (GET)
    @GET("profile")
    Call<ApiResponse> getProfile(@Header("Authorization") String token);

    // ✅ Update profile (PUT)
    @PUT("profile")
    Call<ApiResponse> updateProfile(@Header("Authorization") String token, @Body User user);


    // ======================================================
    // ✅ AUTH / LOGIN / REGISTER
    // ======================================================
    @POST("login")
    Call<LoginResponse> login(@Body LoginRequest request);

    @POST("register")
    Call<ApiResponse> registerUser(@Body RegisterRequest request);

    @POST("register")
    Call<ApiResponse> register(@Body User user);

    @POST("forgot-password")
    Call<ApiResponse> forgotPassword(@Body ForgotPasswordRequest request);

    @POST("verify-reset-code")
    Call<ApiResponse> verifyCode(@Body VerifyCodeRequest request);

    @POST("reset-password")
    Call<ApiResponse> resetPassword(@Body ResetPasswordRequest request);


    // ======================================================
    // ✅ PRODUCTS
    // ======================================================
    @GET("gallons")
    Call<List<ProductDto>> getGallons();

    @GET("gallons/{id}")
    Call<ProductDto> getGallon(@Path("id") int id);


    // ======================================================
    // ✅ ADDRESSES
    // ======================================================
    @GET("addresses")
    Call<AddressResponse> getAddresses(@Header("Authorization") String token);

    @POST("addresses")
    Call<ApiResponse> createAddress(@Header("Authorization") String token, @Body Address body);

    @PUT("addresses/{id}")
    Call<ApiResponse> updateAddress(@Header("Authorization") String token, @Path("id") int id, @Body Address body);

    @DELETE("addresses/{id}")
    Call<ApiResponse> deleteAddress(@Header("Authorization") String token, @Path("id") int id);

    @POST("addresses/{id}/default")
    Call<ApiResponse> setDefaultAddress(@Header("Authorization") String token, @Path("id") int id);


    // ======================================================
    // ✅ ORDERS
    // ======================================================
    @POST("orders")
    Call<ApiResponse> placeOrder(@Body OrderRequest request);

    @GET("orders/latest")
    Call<ApiResponse> getLatestOrders(@Header("Authorization") String token);


    // ======================================================
    // ✅ CART
    // ======================================================
    @GET("cartItems")
    Call<List<com.example.waterrefilldraftv1.Customer.models.ServerCartItem>> getCartItems(@Header("Authorization") String token);

    @POST("cartItems")
    Call<ApiResponse> addToCart(@Header("Authorization") String token, @Body Map<String, Object> body);

    @DELETE("cartItems")
    Call<ApiResponse> removeFromCart(@Header("Authorization") String token, @Body Map<String, List<Integer>> body);

    @PUT("cartItems/decrease")
    Call<ApiResponse> decreaseCartItem(@Header("Authorization") String token, @Body Map<String, Integer> body);

    @PUT("cartItems/increase")
    Call<ApiResponse> increaseCartItem(@Header("Authorization") String token, @Body Map<String, Integer> body);


    // ======================================================
    // ✅ OPTIONAL FULL URL ENDPOINTS (for JSON URLs)
    // ======================================================
    @GET
    Call<List<ProductDto>> getCustomerContainerJson(@Url String fullUrl);

    @GET
    Call<List<com.example.waterrefilldraftv1.Customer.models.CartItem>> getCustomerCartJson(@Url String fullUrl);
}
