package com.example.waterrefilldraftv1.Customer.models;

import com.google.gson.annotations.SerializedName;

public class OrderOverview {
    @SerializedName("order_id")
    public int orderId;
    @SerializedName("total_amount")
    public double totalAmount;
    @SerializedName("status")
    public String status;
    @SerializedName("created_at")
    public String createdAt;
    @SerializedName("order_items")
    public String orderItems; // comma separated summary per backend latest endpoint
}





