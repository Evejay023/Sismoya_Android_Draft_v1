package com.example.waterrefilldraftv1.Customer.UserInterface.fragment;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.waterrefilldraftv1.Customer.models.ApiResponse;
import com.example.waterrefilldraftv1.Customer.models.User;
import com.example.waterrefilldraftv1.Customer.network.ApiService;
import com.example.waterrefilldraftv1.Customer.network.RetrofitClient;
import com.example.waterrefilldraftv1.R;
import com.google.gson.Gson;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DashboardFragment extends Fragment {

    private static final String TAG = "DashboardFragment";
    private static final String ARG_USER = "arg_user";

    private User currentUser;
    private TextView tvPending, tvCompleted, tvCancelled, tvTotal, tvCustomerName;

    public static DashboardFragment newInstance(User user) {
        DashboardFragment fragment = new DashboardFragment();
        Bundle args = new Bundle();
        args.putString(ARG_USER, new Gson().toJson(user));
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.customer_fragment_dashboard, container, false);

        // Initialize UI
        tvCustomerName = view.findViewById(R.id.tv_customer_name);
        tvPending = view.findViewById(R.id.tv_pending_orders);
        tvCompleted = view.findViewById(R.id.tv_completed_orders);
        tvCancelled = view.findViewById(R.id.tv_cancelled_orders);
        tvTotal = view.findViewById(R.id.tv_total_orders);

        // Load current user info
        if (getArguments() != null) {
            String userJson = getArguments().getString(ARG_USER);
            currentUser = new Gson().fromJson(userJson, User.class);
        }

        // Display user name
        if (tvCustomerName != null && currentUser != null) {
            String fullName = (currentUser.getFirstName() != null ? currentUser.getFirstName() : "")
                    + " " +
                    (currentUser.getLastName() != null ? currentUser.getLastName() : "");
            tvCustomerName.setText(fullName.trim());
        }

        // Fetch (or skip) backend stats
        fetchStatsAndLatest(view.getContext());

        return view;
    }

    private void fetchStatsAndLatest(Context ctx) {
        SharedPreferences sp = ctx.getSharedPreferences("MyAppPrefs", Context.MODE_PRIVATE);
        String token = sp.getString("token", null);
        if (token == null) {
            Log.w(TAG, "Missing token — user not logged in?");
            return;
        }

        ApiService api = RetrofitClient.getInstance().create(ApiService.class);

        // 🟡 Since /orders/stats no longer exists
        Log.d(TAG, "Order stats endpoint not available — skipping stats fetch.");

        // Optionally, you can set them all to zero to avoid empty UI
        if (tvPending != null) tvPending.setText("0");
        if (tvCompleted != null) tvCompleted.setText("0");
        if (tvCancelled != null) tvCancelled.setText("0");
        if (tvTotal != null) tvTotal.setText("0");

        // Still fetch latest orders if backend supports it
        api.getLatestOrders("Bearer " + token).enqueue(new Callback<ApiResponse>() {
            @Override
            public void onResponse(@NonNull Call<ApiResponse> call,
                                   @NonNull Response<ApiResponse> response) {
                if (response.isSuccessful() && response.body() != null && !response.body().isError()) {
                    Log.d(TAG, "Latest orders retrieved successfully");
                } else {
                    Log.w(TAG, "No latest orders found");
                }
            }

            @Override
            public void onFailure(@NonNull Call<ApiResponse> call, @NonNull Throwable t) {
                Log.e(TAG, "Failed to fetch latest orders: " + t.getMessage());
            }
        });
    }
}
