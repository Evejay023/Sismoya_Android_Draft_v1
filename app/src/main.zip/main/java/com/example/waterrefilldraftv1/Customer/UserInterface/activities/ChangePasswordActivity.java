package com.example.waterrefilldraftv1.Customer.UserInterface.activities;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.waterrefilldraftv1.Customer.models.ApiResponse;
import com.example.waterrefilldraftv1.Customer.network.NetworkManager;
import com.example.waterrefilldraftv1.R;

public class ChangePasswordActivity extends AppCompatActivity {

    private ImageView ivBack;
    private EditText etCurrentPassword, etNewPassword, etConfirmPassword;
    private Button btnSave;
    private NetworkManager networkManager;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.customer_activity_change_password);

        ivBack = findViewById(R.id.iv_back);
        etCurrentPassword = findViewById(R.id.et_current_password);
        etNewPassword = findViewById(R.id.et_new_password);
        etConfirmPassword = findViewById(R.id.et_confirm_password);
        btnSave = findViewById(R.id.btn_save);
        networkManager = new NetworkManager(this);

        ivBack.setOnClickListener(v -> onBackPressed());
        btnSave.setOnClickListener(this::onSaveClicked);
    }

    private void onSaveClicked(View v) {
        String oldPw = etCurrentPassword.getText().toString();
        String newPw = etNewPassword.getText().toString();
        String confirmPw = etConfirmPassword.getText().toString();

        if (TextUtils.isEmpty(oldPw)) { etCurrentPassword.setError("Required"); etCurrentPassword.requestFocus(); return; }
        if (TextUtils.isEmpty(newPw)) { etNewPassword.setError("Required"); etNewPassword.requestFocus(); return; }
        if (!newPw.equals(confirmPw)) { etConfirmPassword.setError("Passwords do not match"); etConfirmPassword.requestFocus(); return; }

        btnSave.setEnabled(false);

        // Hook up to backend when endpoint added to NetworkManager
        if (networkManager instanceof com.example.waterrefilldraftv1.Customer.network.NetworkManager) {
            // Placeholder until we add changePassword() in NetworkManager
            Toast.makeText(this, "Submitting password change...", Toast.LENGTH_SHORT).show();
        }

        btnSave.setEnabled(true);
        Toast.makeText(this, "Password updated", Toast.LENGTH_SHORT).show();
        finish();
    }
}




