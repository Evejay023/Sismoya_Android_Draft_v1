package com.example.waterrefilldraftv1.Customer.models;

import com.google.gson.annotations.SerializedName;

public class OrderStats {
    @SerializedName("pending")
    public int pending;
    @SerializedName("completed")
    public int completed;
    @SerializedName("cancelled")
    public int cancelled;
    @SerializedName("total")
    public int total;
}





